<div class="container" align="center">

	<div class="col-md-2">
	    	<div id="navbar" class="navbar-collapse collapse">
	            <ul class="nav navbar-nav">	            	
	            	<a href="http://<?php echo APP_HOST; ?>/usuario" class="btn btn-success btn-sm">Usuários</a>
	            </ul>
            </div>
	    </div>
    
    <div class="starter-template">
            <h1><?php echo TITLE; ?></h1>
    </div>

	<div class="row" >
		<div class="col-md-2"></div>

	    <div class="col-md-2">
	    	<div id="navbar" class="navbar-collapse collapse">
	            <ul class="nav navbar-nav">	            	
	            	<a href="http://<?php echo APP_HOST; ?>/usuario" class="btn btn-success btn-sm">Usuários</a>
	            </ul>
            </div>
	    </div>

	    <div class="col-md-2">
	    	<div id="navbar" class="navbar-collapse collapse">
	            <ul class="nav navbar-nav">	            	
	            	<a href="http://<?php echo APP_HOST; ?>/produto" class="btn btn-success btn-sm">Produto</a>
	            </ul>
            </div>
	    </div>

	</div>
</div>
