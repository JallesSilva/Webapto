<div class="container" align="center">

<br><br>	
	<div class="row" >
		<div class="col-md-12"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 1</div>
	</div>

	<div class="row" >
		<div class="col-md-2"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 1</div>
		<div class="col-md-2"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 2</div>
		<div class="col-md-2"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 3</div>
		<div class="col-md-2"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 4</div>
		<div class="col-md-2"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 5</div>
		<div class="col-md-2"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 6</div>
	</div>

	<br>	
	<div class="row" >
		<div class="col-md-6"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 1</div>
		<div class="col-md-6"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 2</div>
	</div>
	
	<br>
	<div class="row" >
		<div class="col-md-4"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 1</div>
		<div class="col-md-4"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 2</div>
		<div class="col-md-4"><img src=http://<?php echo APP_HOST; ?>/public/images/foto.png gwidth="50" height="50"/> 3</div>
	</div>
	<br>

</div>
<br>
