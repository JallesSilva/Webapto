<!--    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#home">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="http://<?php echo APP_HOST; ?>/home">                  
                    <?php echo TITLE; ?>                
                </a>
            </div>
            <div class="collapse navbar-collapse" id="home">
              <ul class="nav navbar-nav navbar-right">
                <li><a href="#about">ABOUT</a></li>
                <li><a href="#services">SERVICES</a></li>
                <li><a href="#portfolio">PORTFOLIO</a></li>
                <li><a href="#pricing">PRICING</a></li>
                <li><a href="#contact">CONTACT</a></li>
              </ul>
            </div>
        </div>
    </nav> 
    <div class="jumbotron text-center" >
      <br><br>
      <h1>Clínica Pelle Estética</h1>      
      <form>
        <div class="input-group">-->
          <!-- <input type="email" class="form-control" size="50" placeholder="Email Address" required> 
          <div class="input-group-btn">-->
          <!-- <button type="button" class="btn btn-danger">Subscribe</button> 
          </div>
        </div>
      </form>
    </div>-->