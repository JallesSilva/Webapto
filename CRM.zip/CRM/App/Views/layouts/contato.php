  
        <div class="container">
        	<div class="row">
        		<footer>

		            <p class="text-muted">
		                Direitos Reservados @Jalles.Silva - Sistemas Web
		            </p>
	            </footer>
            </dir>
        </div>
    