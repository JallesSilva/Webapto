<?php

namespace App\Models\Validacao;

use \App\Models\Validacao\ResultadoValidacao;
use \App\Models\DAO\LoginDAO;

class LoginValidador{


}